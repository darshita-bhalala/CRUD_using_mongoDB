const express = require('express');
var router = express.Router();
const mongoose = require('mongoose');
const Employee = mongoose.model('Employee');

router.get('/',(req,res)=>{
    res.render("employee/addoredit" , {ViewTitle : "Insert employee"});
});

router.post('/',(req,res)=>{
    Insertrecord(req,res);
});

function Insertrecord(req,res){
    var employee = new Employee();
    employee.fullname = req.body.fullname;
    employee.email = req.body.email;
    employee.mobile = req.body.mobile;
    employee.city = req.body.city;
    employee.save((err,doc)=>{
        if(!err){
            console.log('success');
            res.render('employee/list');
        }
        else{
            if(err.name == 'ValidationError')
            {
                handlevalidationerror(err,req.body);
                res.render('employee/addoredit' , {
                    ViewTitle : "Insert employee",
                    employee: req.body
                });
            }
            console.log('error during insert record ' + err);
        }
    });
}

function handlevalidationerror(err,body){
    for(field in err.errors){
        switch(err.errors[field].path){
            case 'fullname':
                body["FullnameError"]=err.errors[field].message;
                break;
            case 'email':
                body["EmailError"]=err.errors[field].message;
                break;
            default:
                break;
        }
    }
}

router.get('/list',(req,res)=>{
    var employee = new Employee();
    Employee.find((err,emp)=>{
        if(!err){
            console.log(emp);
            res.render("employee/list" , {
                employee: emp
            });
            console.log('list success');
        }

        else
        {
            console.log("error in listing record" + err);
        }
    });
});

module.exports = router;