const mongoose = require('mongoose');

var employeeschema = new mongoose.Schema({
    fullname : {
        type : String,
        required : 'Full Name is Required'
    },
    email : {
        type : String,
        required : 'Email is Required'
    },
    mobile : {
        type : String
    },
    city : {
        type : String
    }
});

//custom validation for email

// employeeschema.path('email'.validate((val)=>{
//     emailregex = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/1;
//     return emailregex.test(val);
//     }),
//     'Invalid Email');
mongoose.model('Employee',employeeschema);