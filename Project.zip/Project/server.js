require('./Models/db');
const express = require('express');
const employeecontroller = require('./Controller/EmployeeController');
const path = require('path');
//const handlebars = require ('handelbars');
const exphbs = require('express-handlebars');
//const {allowInsecurePrototypeAccess} = require('@handlebars/allow-prototype-access');
const bodyParser = require('body-parser');
var app=express();
app.use(bodyParser.urlencoded({
    extended : true
}));
app.use(bodyParser.json());
app.set('views',path.join(__dirname,'/views/'));
app.engine('hbs',exphbs({ extname : 'hbs' , defaultLayout : 'mainLayout' , layoutsDir : __dirname + '/views/layouts/'}));
app.set('view engine','hbs');
app.listen(3000,()=>{
    console.log('Express server is started on port : 3000');
});

app.use('/employee',employeecontroller);